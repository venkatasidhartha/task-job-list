from django.db import models

# Create your models here.
class Job_list(models.Model):
    job_name = models.CharField(max_length=100)
    job_dec = models.CharField(max_length=1000)
    company_name = models.CharField(max_length=200)
    job_Exp = models.CharField(max_length=100)
    job_salary = models.CharField(max_length=100)