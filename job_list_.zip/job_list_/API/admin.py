from django.contrib import admin
from .models import Job_list
# Register your models here.
admin.site.register(Job_list)