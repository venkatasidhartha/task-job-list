from rest_framework import serializers
from .models import Job_list

class Job_serial(serializers.ModelSerializer):
    class Meta:
        model = Job_list
        fields = '__all__'
