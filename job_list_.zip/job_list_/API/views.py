from django.shortcuts import render
from .models import Job_list
from .serilizer import Job_serial
from rest_framework import viewsets
from rest_framework.response import Response
# Create your views here.

class Job_list_viewsets(viewsets.ModelViewSet):
    queryset = Job_list.objects.all()
    serializer_class = Job_serial
    http_method_names = ['get','post','delete','put']

